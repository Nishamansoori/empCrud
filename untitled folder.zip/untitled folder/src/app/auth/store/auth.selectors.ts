export const AUTH_STATE_NAME = 'auth';
