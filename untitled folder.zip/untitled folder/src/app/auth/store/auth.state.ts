export interface AuthState {}

export const initialState: AuthState = {};
